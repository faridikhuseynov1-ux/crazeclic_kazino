Deploy this bot+miniapp to Railway or similar.
